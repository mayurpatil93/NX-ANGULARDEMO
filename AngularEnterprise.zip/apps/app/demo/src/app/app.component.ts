import { Component } from '@angular/core';


@Component({
  selector: 'AngularEnterprise-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app-demo';
}
