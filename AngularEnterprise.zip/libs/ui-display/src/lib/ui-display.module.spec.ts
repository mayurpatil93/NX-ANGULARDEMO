import { async, TestBed } from '@angular/core/testing';
import { UiDisplayModule } from './ui-display.module';

describe('UiDisplayModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [UiDisplayModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(UiDisplayModule).toBeDefined();
  });
});
