import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UidisplayComponent } from './uidisplay.component';

describe('UidisplayComponent', () => {
  let component: UidisplayComponent;
  let fixture: ComponentFixture<UidisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UidisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UidisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
