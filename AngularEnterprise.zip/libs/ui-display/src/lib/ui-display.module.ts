import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { ReactiveFormsModule } from '@angular/forms';
import {MaterialModule} from './material.module';


import { UidisplayComponent } from './uidisplay/uidisplay.component';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule, 
    BrowserAnimationsModule, 
    ReactiveFormsModule, 
    MaterialModule,

    RouterModule.forChild([
       {path: '', pathMatch: 'full', component: UidisplayComponent} 
    ])
  ],
  declarations: [UidisplayComponent]
})
export class UiDisplayModule {}
